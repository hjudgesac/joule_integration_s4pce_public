1. Switch to BTP Cockpit browser tab.
2. From the Navigation Pane on the left, select **Security >> Trust Configuration** and click the pencil icon next to **Default Identity Provider**.</br>  
![create_content_provider](9.jpg)   

3. Uncheck **Available for User Logon** and click **Save**.</br>        
![run_booster](10.jpg)         
**Note**: This change is made so that the end user doesn't get prompted to pick an Identity Provider when launching Joule in SuccessFactors.
